# IT_Assesment
Word Document Task:

s3878010 - Duc Anh - Tool and technologies

s4105153 - Lam - Overview Testing

s3747702 - Khoi - Risk and group progress

s3924472 - Tri - Role & Timeframe

s3977880 - Viet - Aims, scope
 
Coding Task: Same as word document

MOM (Minutes of meetings):

Friday 15/9/2023 - Google doc format final review then coding task divided for each individuals

